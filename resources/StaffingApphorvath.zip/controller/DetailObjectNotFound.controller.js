sap.ui.define(["./BaseController"],function(t){"use strict";return t.extend("StaffingApp.horvath.controller.DetailObjectNotFound",{})});
//# sourceMappingURL=DetailObjectNotFound.controller.js.map