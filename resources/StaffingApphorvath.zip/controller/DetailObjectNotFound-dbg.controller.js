sap.ui.define([
    "./BaseController"
], function (BaseController) {
    "use strict";

    return BaseController.extend("StaffingApp.horvath.controller.DetailObjectNotFound", {});
});